<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Tracking Update</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { width: 100%; max-width: 600px; margin: 20px auto; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
        .header { background-color: #0B3B60; color: #fff; padding: 10px 20px; text-align: center; border-radius: 5px 5px 0 0; }
        .header h1 { margin: 0; font-size: 24px; }
        .content { padding: 20px; }
        .content h2 { color: #E32726; }
        .footer { text-align: center; font-size: 12px; color: #777; margin-top: 20px; }
        .button { display: inline-block; background-color: #E32726; color: #fff; padding: 10px 20px; text-decoration: none; border-radius: 5px; }
        .info-box { background-color: #f9f9f9; border: 1px solid #eee; padding: 15px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Pets Travel International</h1>
        </div>
        <div class="content">
            <p>Hello <?php echo e($tracking->owner_name); ?>,</p>

            <?php if($isNewTracking ?? false): ?>
                <h2>Your Pet's Tracking Has Been Created!</h2>
                <p>A new tracking has been created for your pet, <strong><?php echo e($tracking->pet_name); ?></strong>.</p>
                <div class="info-box">
                    <p><strong>Tracking Number:</strong> <?php echo e($tracking->tracking_number); ?></p>
                    <p><strong>Pet Type:</strong> <?php echo e(ucfirst($tracking->pet_type)); ?></p>
                    <?php if($tracking->pet_breed): ?>
                        <p><strong>Breed:</strong> <?php echo e($tracking->pet_breed); ?></p>
                    <?php endif; ?>
                    <p><strong>Origin:</strong> <?php echo e($tracking->origin); ?></p>
                    <p><strong>Destination:</strong> <?php echo e($tracking->destination); ?></p>
                    <p><strong>Departure Date:</strong> <?php echo e(date('F j, Y', strtotime($tracking->departure_date))); ?></p>
                    <p><strong>Estimated Arrival:</strong> <?php echo e(date('F j, Y', strtotime($tracking->estimated_arrival_date))); ?></p>
                    <p><strong>Current Status:</strong> <?php echo e(ucfirst(str_replace('_', ' ', $tracking->status))); ?></p>
                </div>
                <p>You can use your tracking number to check the status of your pet's journey at any time by visiting our tracking page:</p>
                <a href="<?php echo e(route('tracking.index')); ?>" class="button">Track Your Pet</a>
            <?php elseif($trackingUpdate): ?>
                <h2>A New Update on Your Pet's Journey!</h2>
                <p>There's a new update for your pet, <strong><?php echo e($tracking->pet_name); ?></strong> (Tracking #: <?php echo e($tracking->tracking_number); ?>).</p>
                <div class="info-box">
                    <p><strong>Status:</strong> <?php echo e(ucfirst(str_replace('_', ' ', $trackingUpdate->status))); ?></p>
                    <p><strong>Location:</strong> <?php echo e($trackingUpdate->location); ?></p>
                    <?php if($trackingUpdate->description): ?>
                        <p><strong>Details:</strong> <?php echo e($trackingUpdate->description); ?></p>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <h2>Your Pet's Tracking Information Has Been Updated</h2>
                <p>The core details for your pet, <strong><?php echo e($tracking->pet_name); ?></strong> (Tracking #: <?php echo e($tracking->tracking_number); ?>), have been updated. Please review the changes to ensure everything is correct.</p>
            <?php endif; ?>

            <p>You can view the full journey details by clicking the button below:</p>
            <p style="text-align:center;">
                <a href="<?php echo e(route('tracking.show', ['tracking_number' => $tracking->tracking_number])); ?>" class="button">View Tracking Details</a>
            </p>
            <p>Thank you for trusting Pets Travel International.</p>
        </div>
        <div class="footer">
            <p>&copy; <?php echo e(date('Y')); ?> Pets Travel International. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pettrack\resources\views/emails/tracking_updated.blade.php ENDPATH**/ ?>