<?php $__env->startSection('title', 'Manage Pet Trackings - Admin Dashboard'); ?>
<?php $__env->startSection('header', 'Pet Trackings'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white rounded-lg shadow-md p-4 sm:p-6">
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div class="flex items-center">
            <h1 class="text-xl sm:text-2xl font-bold">All Trackings</h1>
            <span class="ml-3 bg-gray-100 text-gray-700 px-2 py-1 rounded-full text-xs font-medium"><?php echo e($trackings->total()); ?></span>
        </div>
        <a href="<?php echo e(route('admin.trackings.create')); ?>" class="w-full sm:w-auto bg-brand-red hover:bg-opacity-90 text-white font-medium py-2 px-4 rounded flex items-center justify-center">
            <i class="fas fa-plus mr-2"></i> New Tracking
        </a>
    </div>

    <?php if($trackings->count() > 0): ?>
        <!-- Desktop Table View (hidden on mobile) -->
        <div class="hidden md:block overflow-x-auto">
            <table class="min-w-full bg-white border border-gray-200">
                <thead>
                    <tr>
                        <th class="py-3 px-4 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">Tracking #</th>
                        <th class="py-3 px-4 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">Pet Name</th>
                        <th class="py-3 px-4 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">Origin</th>
                        <th class="py-3 px-4 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">Destination</th>
                        <th class="py-3 px-4 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">Status</th>
                        <th class="py-3 px-4 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">Created</th>
                        <th class="py-3 px-4 bg-gray-100 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider border-b">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__currentLoopData = $trackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tracking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="hover:bg-gray-50">
                            <td class="py-3 px-4 border-b"><?php echo e($tracking->tracking_number); ?></td>
                            <td class="py-3 px-4 border-b"><?php echo e($tracking->pet_name); ?></td>
                            <td class="py-3 px-4 border-b"><?php echo e($tracking->origin); ?></td>
                            <td class="py-3 px-4 border-b"><?php echo e($tracking->destination); ?></td>
                            <td class="py-3 px-4 border-b">
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                    <?php if($tracking->status == 'pending'): ?> bg-yellow-100 text-yellow-800
                                    <?php elseif($tracking->status == 'in_transit'): ?> bg-blue-100 text-blue-800
                                    <?php elseif($tracking->status == 'delivered'): ?> bg-green-100 text-green-800
                                    <?php elseif($tracking->status == 'delayed'): ?> bg-red-100 text-red-800
                                    <?php endif; ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $tracking->status))); ?>

                                </span>
                            </td>
                            <td class="py-3 px-4 border-b"><?php echo e($tracking->created_at->format('M j, Y')); ?></td>
                            <td class="py-3 px-4 border-b text-sm">
                                <div class="flex space-x-2">
                                    <a href="<?php echo e(route('admin.trackings.show', $tracking)); ?>" class="text-dark-blue hover:text-opacity-80" title="View Details">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.trackings.edit', $tracking)); ?>" class="text-orange hover:text-opacity-80" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.trackings.updates.create', $tracking)); ?>" class="text-green-600 hover:text-opacity-80" title="Add Update">
                                        <i class="fas fa-plus-circle"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.trackings.destroy', $tracking)); ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this tracking?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="text-brand-red hover:text-opacity-80" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <!-- Mobile Card View (hidden on desktop) -->
        <div class="md:hidden grid grid-cols-1 gap-4">
            <?php $__currentLoopData = $trackings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tracking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
                    <div class="p-4 border-b border-gray-200 flex justify-between items-center">
                        <div>
                            <h3 class="text-lg font-medium text-gray-800"><?php echo e($tracking->pet_name); ?></h3>
                            <p class="text-sm text-gray-500"><?php echo e($tracking->tracking_number); ?></p>
                        </div>
                        <span class="px-2.5 py-1 text-xs font-semibold rounded-full
                            <?php if($tracking->status == 'pending'): ?> bg-yellow-100 text-yellow-800
                            <?php elseif($tracking->status == 'in_transit'): ?> bg-blue-100 text-blue-800
                            <?php elseif($tracking->status == 'delivered'): ?> bg-green-100 text-green-800
                            <?php elseif($tracking->status == 'delayed'): ?> bg-red-100 text-red-800
                            <?php endif; ?>">
                            <?php echo e(ucfirst(str_replace('_', ' ', $tracking->status))); ?>

                        </span>
                    </div>
                    
                    <div class="p-4 space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Origin:</span>
                            <span class="text-gray-900 font-medium"><?php echo e($tracking->origin); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Destination:</span>
                            <span class="text-gray-900 font-medium"><?php echo e($tracking->destination); ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Created:</span>
                            <span class="text-gray-900"><?php echo e($tracking->created_at->format('M j, Y')); ?></span>
                        </div>
                    </div>
                    
                    <div class="border-t border-gray-200 p-3 bg-gray-50 flex justify-between">
                        <a href="<?php echo e(route('admin.trackings.show', $tracking)); ?>" class="inline-flex items-center text-sm text-dark-blue hover:underline">
                            <i class="fas fa-eye mr-1"></i> View
                        </a>
                        <a href="<?php echo e(route('admin.trackings.edit', $tracking)); ?>" class="inline-flex items-center text-sm text-orange hover:underline">
                            <i class="fas fa-edit mr-1"></i> Edit
                        </a>
                        <a href="<?php echo e(route('admin.trackings.updates.create', $tracking)); ?>" class="inline-flex items-center text-sm text-green-600 hover:underline">
                            <i class="fas fa-plus-circle mr-1"></i> Update
                        </a>
                        <form action="<?php echo e(route('admin.trackings.destroy', $tracking)); ?>" method="POST" class="inline" onsubmit="return confirm('Are you sure you want to delete this tracking?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="inline-flex items-center text-sm text-brand-red hover:underline">
                                <i class="fas fa-trash mr-1"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="mt-6 px-2 sm:px-0">
            <?php echo e($trackings->links()); ?>

        </div>
    <?php else: ?>
        <div class="bg-gray-50 p-6 text-center rounded-lg border border-gray-200">
            <div class="py-6">
                <div class="flex justify-center mb-4">
                    <i class="fas fa-shipping-fast text-4xl text-gray-400"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-700 mb-1">No trackings found</h3>
                <p class="text-gray-500 mb-4">Get started by creating your first tracking</p>
                <a href="<?php echo e(route('admin.trackings.create')); ?>" class="inline-flex items-center px-4 py-2 bg-brand-red text-white rounded-md hover:bg-opacity-90 transition">
                    <i class="fas fa-plus mr-2"></i> New Tracking
                </a>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pettrack\resources\views/admin/trackings/index.blade.php ENDPATH**/ ?>